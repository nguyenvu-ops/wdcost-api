export default function handler(req, res) {
  res.json({ status: "WD Cost API Ready" });
}